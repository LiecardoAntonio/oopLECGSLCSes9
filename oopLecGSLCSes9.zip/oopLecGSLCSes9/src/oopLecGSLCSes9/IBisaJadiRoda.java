package oopLecGSLCSes9;

public interface IBisaJadiRoda {
	// class interface yang mengindikasikan sebuah class untuk bisa menjadi roda kendaraan
	
	void jadiRoda();
}
